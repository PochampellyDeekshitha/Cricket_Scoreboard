let teamRuns = 0, wickets = 0, balls = 0, overs = 0;
let rahulRuns = 0, rohitRuns = 0;
let striker = "Rahul";
let isFreeHit = false;

function updateDisplay() {
  document.getElementById("teamScore").innerText = `${teamRuns}/${wickets}`;
  document.getElementById("overs").innerText = `${overs}.${balls} Overs`;

  let rahulText = `Rahul: ${rahulRuns}`;
  let rohitText = `Rohit: ${rohitRuns}`;

  if (striker === "Rahul") rahulText += "*";
  else rohitText += "*";

  document.getElementById("rahul").innerText = rahulText;
  document.getElementById("rohit").innerText = rohitText;

  document.getElementById("rahul").classList.toggle("striker", striker === "Rahul");
  document.getElementById("rohit").classList.toggle("striker", striker === "Rohit");
}

function validBall() {
  balls++;
  if (balls === 6) {
    overs++;
    balls = 0;
  }
}

function addRun(runs) {
  teamRuns += runs;
  if (striker === "Rahul") rahulRuns += runs;
  else rohitRuns += runs;

  if (!isFreeHit) validBall();
  else isFreeHit = false;

  if (runs % 2 !== 0) switchStriker();
  updateDisplay();
}

function wide() {
  teamRuns++;
  updateDisplay();
}

function noBall() {
  teamRuns++;
  if (striker === "Rahul") rahulRuns++;
  else rohitRuns++;
  // no ball = no valid ball
  updateDisplay();
}

function freeHit() {
  teamRuns++;
  isFreeHit = true;
  updateDisplay();
}

function bye() {
  teamRuns++;
  validBall();
  switchStriker();
  updateDisplay();
}

function legBye() {
  teamRuns++;
  validBall();
  switchStriker(); 
  updateDisplay();
}

function wicket() {
  if (isFreeHit) {
    alert("No wicket on Free Hit!");
    isFreeHit = false;
    return;
  }
  wickets++;
  if (wickets > 10) wickets = 10;
  validBall();
  striker = "Rahul"; 
  updateDisplay();
}

function lbw() {
  wicket();
}

function switchStriker() {
  striker = (striker === "Rahul") ? "Rohit" : "Rahul";
  updateDisplay();
}

function resetGame() {
  teamRuns = wickets = balls = overs = 0;
  rahulRuns = rohitRuns = 0;
  striker = "Rahul";
  isFreeHit = false;
  updateDisplay();
}

updateDisplay();